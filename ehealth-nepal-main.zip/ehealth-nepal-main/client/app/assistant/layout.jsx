import React from 'react'

const AssistantLayout = ({children}) => {
  return (
    <div>{children}</div>
  )
}

export default AssistantLayout;
