export default function RegisterLayout({ children }) {
  return <div>{children}</div>;
}
