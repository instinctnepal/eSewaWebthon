import React from 'react'

export default function AuthLayout({ children }) {
  return (
    <div>{children}</div>
  )
}
